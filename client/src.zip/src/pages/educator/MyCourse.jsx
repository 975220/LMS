import React from 'react'

const MyCourse = () => {
  return (
    <div>
      <h1> pages MyCourse</h1>
    </div>
  )
}

export default MyCourse
