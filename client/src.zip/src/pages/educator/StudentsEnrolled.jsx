import React from 'react'

const StudentsEnrolled = () => {
  return (
    <div>
      <h1>StudentsEnrolled</h1>
    </div>
  )
}

export default StudentsEnrolled
