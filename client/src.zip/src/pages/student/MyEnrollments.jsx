import React from 'react'

const MyEnrollments = () => {
  return (
    <div>
      <h1>pages MyEnrollments</h1>
    </div>
  )
}

export default MyEnrollments
