import React from 'react'

const Players = () => {
  return (
    <div>
      <h1> pages Players</h1>
    </div>
  )
}

export default Players
