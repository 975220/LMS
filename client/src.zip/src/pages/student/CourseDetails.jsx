import React, { useEffect, useState, useContext } from 'react';
import { useParams } from 'react-router-dom';
import { AppContext } from '../../context/AppContext';
import Loading from '../../components/students/Loading';
import { assets } from '../../assets/assets';
import Footer from '../../components/students/Footer';
import humanizeDuration from 'humanize-duration';
import YouTube from 'react-youtube';

const CourseDetails = () => {
  const { id } = useParams();
  const [courseData, setCourseData] = useState(null);
  const [openSection, setOpenSection] = useState({});
  const [isAlreadyEnrolled, setIsAlreadyEnrolled] = useState(false);
  const [playerData, setPlayerData] = useState(null);

  const {
    allCourses,
    calculateRating,
    calculateTotalLectures,
    calculateCourseDuration,
    calculateChapterTime,
    currency,
  } = useContext(AppContext);

  useEffect(() => {
    if (allCourses.length > 0) {
      const findCourse = allCourses.find((course) => course.id === id);
      setCourseData(findCourse);
    }
  }, [allCourses, id]);

  const toggleSection = (index) => {
    setOpenSection((prev) => ({ ...prev, [index]: !prev[index] }));
  };

  const calculateDiscountPrice = (price, discount) => {
    return (price - (discount * price) / 100).toFixed(2);
  };

  if (!courseData) return <Loading />;

  return (
    <>
      <div className="p-4 md:flex gap-8">
        {/* Left Column */}
        <div className="flex-1">
          <h1 className="text-3xl font-bold mb-4">{courseData.courseTitle}</h1>
          <p dangerouslySetInnerHTML={{ __html: courseData.courseDescription.slice(0, 200) }} />

          {/* Rating */}
          <div className="rating mb-4">
            <p>{calculateRating(courseData).toFixed(1)}</p>
            <div className="flex gap-1">
              {[...Array(5)].map((_, i) => (
                <img
                  key={i}
                  src={i < Math.round(calculateRating(courseData)) ? assets.star : assets.star_blank}
                  alt="star"
                />
              ))}
            </div>
            <p>
              ({courseData.courseRating.length} {courseData.courseRating.length > 1 ? 'Reviews' : 'Rating'})
            </p>
            <p>
              {courseData.enrollments.length}{' '}
              {courseData.enrollments.length > 1 ? 'Students' : 'Student'}
            </p>
          </div>

          <p className="mb-6">Course by <span className="font-semibold">Divyansh Kaurav</span></p>

          <div>
            <h2 className="text-xl font-semibold mb-2">Course Structure</h2>
            {courseData.coursecontent.map((chapter, index) => (
              <div key={index} className="mb-4 border rounded p-2">
                <div onClick={() => toggleSection(index)} className="cursor-pointer flex justify-between items-center">
                  <div className="flex items-center gap-2">
                    <img
                      className={`w-4 transition-transform ${openSection[index] ? 'rotate-180' : ''}`}
                      src={assets.down_arrow_icon}
                      alt="arrow icon"
                    />
                    <p className="font-medium">{chapter.chapterTitle}</p>
                  </div>
                  <p>
                    {chapter.chapterContent.length} Lectures - {calculateChapterTime(chapter)}
                  </p>
                </div>
                {openSection[index] && (
                  <ul className="mt-2">
                    {chapter.chapterContent.map((lecture, i) => (
                      <li key={i} className="flex gap-2 py-2">
                        <img src={assets.play_icon} alt="play icon" className="w-5 h-5 mt-1" />
                        <div>
                          <p className="font-semibold">{lecture.lectureTitle}</p>
                          <div className="text-sm text-gray-600 flex gap-4">
                            {lecture.ispreview && (
                              <p
                                className="text-blue-600 cursor-pointer"
                                onClick={() =>
                                  setPlayerData({ videoId: lecture.lectureurl.split('/').pop() })
                                }
                              >
                                Preview
                              </p>
                            )}
                            <p>
                              {humanizeDuration(lecture.lectureDuration * 60000, {
                                units: ['h', 'm'],
                                round: true,
                              })}
                            </p>
                          </div>
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>

          <div className="mt-8">
            <h3 className="text-xl font-semibold mb-2">Course Description</h3>
            <div dangerouslySetInnerHTML={{ __html: courseData.courseDescription }} className="prose" />
          </div>
        </div>

        {/* Right Column */}
        <div className="w-full md:w-1/3 mt-8 md:mt-0">
          {playerData ? (
            <YouTube
              videoId={playerData.videoId}
              opts={{ playerVars: { autoplay: 1 } }}
              iframeClassName="w-full aspect-video"
            />
          ) : (
            <img
              src={courseData.courseThumbnail}
              alt="Course Thumbnail"
              className="w-full rounded aspect-video object-cover"
            />
          )}

          <div className="mt-4 flex items-center gap-2 text-red-600">
            <img className="w-5 h-5" src={assets.time_left_clock_icon} alt="Time left" />
            <p>
              <span>5 days</span> left at this price!
            </p>
          </div>

          <div className="mt-3 space-y-1">
            <p className="text-2xl font-bold text-green-600">
              {currency}
              {calculateDiscountPrice(courseData.coursePrice, courseData.courseDiscount)}
            </p>
            <p className="line-through text-gray-500">
              {currency}
              {courseData.coursePrice}
            </p>
            <p className="text-sm text-red-500">{courseData.courseDiscount}% off</p>
          </div>

          <div className="mt-4 text-sm text-gray-700 space-y-2">
            <div className="flex gap-2 items-center">
              <img src={assets.star} className="w-4" alt="rating" />
              <p>{calculateRating(courseData).toFixed(1)} Rating</p>
            </div>
            <div className="flex gap-2 items-center">
              <img src={assets.time_clock_icon} className="w-4" alt="duration" />
              <p>{calculateCourseDuration(courseData)}</p>
            </div>
            <div className="flex gap-2 items-center">
              <img src={assets.lesson_icon} className="w-4" alt="lessons" />
              <p>{calculateTotalLectures(courseData)} Lessons</p>
            </div>
          </div>

          <button className="mt-5 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded font-medium">
            {isAlreadyEnrolled ? 'Go to Course' : 'Enroll Now'}
          </button>

          <div className="mt-6">
            <p className="font-semibold mb-2">What's in the course?</p>
            <ul className="list-disc ml-5 text-sm text-gray-700 space-y-1">
              <li>Lifetime access & updates</li>
              <li>Hands-on project guidance</li>
              <li>Downloadable resources</li>
              <li>Quizzes for revision</li>
              <li>Completion certificate</li>
            </ul>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default CourseDetails;