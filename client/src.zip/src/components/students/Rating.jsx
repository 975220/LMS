import React from 'react'

const Rating = () => {
  return (
    <div>
      <h1>Rating </h1>
    </div>
  )
}

export default Rating
