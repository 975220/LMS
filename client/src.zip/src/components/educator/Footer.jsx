import React from 'react'

const Footer = () => {
  return (
    <div>
      edu footer
    </div>
  )
}

export default Footer
