import React from 'react'

const Sidebar = () => {
  return (
    <div>
      <h1>sidebar</h1>
    </div>
  )
}

export default Sidebar
