import React from 'react'

const Navbar = () => {
  return (
    <div>
      <h1>Edu Navbar</h1>
    </div>
  )
}

export default Navbar
